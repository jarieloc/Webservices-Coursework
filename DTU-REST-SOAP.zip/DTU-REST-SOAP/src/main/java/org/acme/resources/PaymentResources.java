package org.acme.resources;

import jakarta.inject.Inject;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.ArrayList;

import org.acme.models.Payment;
import org.acme.models.Customer;
import org.acme.models.Merchant;

@Path("/payments")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PaymentResources {

    private List<Payment> payments = new ArrayList<>();

    @Inject
    private CustomerResources customerResources;

    @Inject
    private MerchantResources merchantResources;

    @POST
    public Response makePayment(Payment payment) {
        // Retrieve customer and merchant
        Customer customer = customerResources.getCustomerById(payment.getCustomerId());
        Merchant merchant = merchantResources.getMerchantById(payment.getMerchantId());

        if (customer == null || merchant == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity("Customer or Merchant not found").build();
        }

        // Populate payment details
        payment.setCustomerName(customer.getFirstName() + " " + customer.getLastName());
        payment.setMerchantName(merchant.getFirstName() + " " + merchant.getLastName());
        payment.setCustomerCpr(customer.getCprNumber());
        payment.setMerchantCpr(merchant.getCprNumber());
        payment.setCustomerBankAccount(customer.getBankAccount());
        payment.setMerchantBankAccount(merchant.getBankAccount());

        // Add payment to the list
        payments.add(payment);

        return Response.status(Response.Status.CREATED).entity(payment).build();
    }

    @GET
    public List<Payment> listPayments() {
        return payments;
    }
}


/* package org.acme.resources;

import jakarta.inject.Inject;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.ArrayList;

import org.acme.models.Payment;
import org.acme.models.Customer;
import org.acme.models.Merchant;

@Path("/payments")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PaymentResources {

    private List<Payment> payments = new ArrayList<>();

    @Inject
    private CustomerResources customerResources;

    @Inject
    private MerchantResources merchantResources;

    @POST
    public Response makePayment(Payment payment) {
        // Retrieve customer and merchant
        Customer customer = customerResources.getCustomerById(payment.getCustomerId());
        Merchant merchant = merchantResources.getMerchantById(payment.getMerchantId());

        if (customer == null || merchant == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity("Customer or Merchant not found").build();
        }

        // Populate payment details
        payment.setCustomerName(customer.getFirstName() + " " + customer.getLastName());
        payment.setMerchantName(merchant.getFirstName() + " " + merchant.getLastName());
        payment.setCustomerCpr(customer.getCpr());
        payment.setMerchantCpr(merchant.getCpr());
        payment.setCustomerBankAccount(customer.getBankAccount());
        payment.setMerchantBankAccount(merchant.getBankAccount());

        // Add payment to the list
        payments.add(payment);

        return Response.status(Response.Status.CREATED).entity(payment).build();
    }

    @GET
    public List<Payment> listPayments() {
        return payments;
    }
}
 */


/* package org.acme.resources;

import jakarta.inject.Inject;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.ArrayList;

import org.acme.models.Payment;


@Path("/payments")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public class PaymentResources {
    private List<Payment> payments = new ArrayList<>();

    @POST
    public Response makePayment(Payment payment) {
        payments.add(payment);
        return Response.status(Response.Status.CREATED).entity(payment).build();
    }

    @GET
    public List<Payment> listPayments(){
        return payments;
    }

}
 */